package kr.or.iei.entities;

/**
 * 포장 vs 매장
 */
public enum PackingType {
    TOGO,
    INDOOR
}
