package kr.or.iei.entities;

public enum  ProductType {
    COFFEE,
    SMOOTHIE,
    CAKE
}
