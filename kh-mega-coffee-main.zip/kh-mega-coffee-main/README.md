

리턴타입 메소드이름 (파라미터) {
    // 메소드 바디
    
}

타입 변수명 = 메소드이름();

OrderProduct get() {
    // 코드
}

OrderProduct op = get();